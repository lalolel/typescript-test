// Write code for the first exercise here and so on.
